from django.shortcuts import render, redirect, get_object_or_404
from .models import Cliente, Produto, Carrinho, Finalizar, Contato, Retirado
from django.contrib import messages
import datetime
from .forms import ProdutoForm
import random


# Create your views here.
def fcliente(request):
    produtos = Produto.objects.all()
    produtosLim = Produto.objects.all()[:3]
    produtosLim2 = Produto.objects.all()[3:6]
    nome = 'Conta'
    return render(request, 'index.html', {"produtos": produtos, "produtosLim":produtosLim, "produtosLim2":produtosLim2, "nome": nome})

def login(request):
    return render(request, 'login.html')

#pagina login/cadastrar
def cadastrarCliente(request):
    cli_nome = request.POST.get("nome")
    cli_telefone = request.POST.get("telefone")
    cli_cpf = request.POST.get("cpf")
    cli_email = request.POST.get("email")
    cli_senha = request.POST.get("senha")
    if Cliente.objects.filter(cpf=cli_cpf).exists():
        msg = 1
        return render(request, 'login.html', {"msg": msg})
    else:
        Cliente.objects.create(nome=cli_nome, telefone=cli_telefone, cpf=cli_cpf, email=cli_email, senha=cli_senha)
        msg = 3
        return render(request, 'login.html', {"msg": msg})
    
def loginCliente(request):
    cli_cpf = request.POST.get("cpf")
    cli_senha = request.POST.get("senha")
    clientes = Cliente.objects.all()
    if cli_cpf == "12917266759" and cli_senha == "admin":
        return render(request, 'admin_cliente.html')
    elif Cliente.objects.filter(cpf=cli_cpf, senha=cli_senha).exists():
        cliente = Cliente.objects.get(cpf=cli_cpf, senha=cli_senha)
        nome = cliente.nome
        value = 1
        produtos = Produto.objects.all()
        produtosLim = Produto.objects.all()[:3]
        produtosLim2 = Produto.objects.all()[3:6]
        return render(request, 'index.html', {"produtos": produtos, "produtosLim":produtosLim, "produtosLim2":produtosLim2, "nome": nome, "value": value})
    else:
        msg = 2
        return render(request, 'login.html', {"msg": msg})

#pagina admin
def cadProduto(request):
    return render(request, 'cadastrar_produto.html')

def cadastrar(request):
    if request.method == 'POST':
        form = ProdutoForm(request.POST, request.FILES)
        if form.is_valid():
            produto = form.save(commit=False)
            produto.imagem = form.cleaned_data['imagem']
            produto.save()
            return render(request, 'cadastrar_produto.html', {'form': form})
    else:
        form = ProdutoForm()
    return render(request, 'mostrar_dados.html', {'form': form})

def mostrarDados(request):
    produtos = Produto.objects.all()
    return render(request, 'mostrar_dados.html', {"produtos": produtos})

#pagina de edição dos produtos
def voltarDados(request):
    return render(request, 'admin_cliente.html')

def editarProduto(request, id):
    produtos = Produto.objects.get(id=id)
    return render(request, 'editar_Produto.html', {"produtos": produtos})

def deleteProduto(request, id):
    produto = Produto.objects.get(id=id)
    produto.delete()
    return redirect(mostrarDados)

def updateProduto(request, id):
    nome_prod = request.POST.get("nome_produto")
    tipo_prod = request.POST.get("tipo")
    qtd_prod = request.POST.get("qtd")
    preco_prod = request.POST.get("preco")
    descricao_prod = request.POST.get("descricao")
    produto = Produto.objects.get(id=id)
    produto.nome_produto = nome_prod
    produto.qtd = qtd_prod
    produto.tipo = tipo_prod
    produto.preco = preco_prod
    produto.descricao = descricao_prod
    produto.save()
    return redirect(mostrarDados)


#carrinho
def comprar(request, id):
    produto = Produto.objects.get(id=id)
    Carrinho.objects.create(nome_produto=produto.nome_produto, quant=1, preco=produto.preco)
    produtos = Produto.objects.all()
    produtosLim = Produto.objects.all()[:3]
    produtosLim2 = Produto.objects.all()[3:6]
    nome = 'Conta'
    comp = 1
    return render(request, 'index.html', {"produtos": produtos, "produtosLim":produtosLim, "produtosLim2":produtosLim2, "nome": nome, "comp":comp})

def carrinho (request):
    preco_total = sum(item.preco for item in Carrinho.objects.all())
    produtos = Carrinho.objects.all()
    imagens = Produto.objects.all()
    return render(request, 'carrinho.html', {"produtos": produtos, "imagens":imagens, "preco_final":preco_total})

def finalizar(request):
    preco_total = sum(item.preco for item in Carrinho.objects.all())
    carrinho = Carrinho.objects.all()
    Finalizar.objects.all().delete()
    
    for item in carrinho:
        # Obtenha a quantidade específica para cada produto
        quantidade = int(request.POST.get(f"quantidade_{item.id}", 1))
        Finalizar.objects.create(
            nome_produto=item.nome_produto,
            quant=quantidade,
            preco=item.preco,
            preco_final=quantidade * item.preco
        )
        
    total_preco = sum(item.preco_final for item in Finalizar.objects.all())
    produtos = Finalizar.objects.all()
    
    return render(request, 'finalizar.html', {"produtos": produtos, "preco_final": total_preco})

def deleteCarrinho(request, id):
    try:
        carrinho = Carrinho.objects.get(id=id)
        carrinho.delete()
    except Carrinho.DoesNotExist:
       print("deu errado")
    return redirect('carrinho')

def imprimir(request, pFinal):
    hora_atual = datetime.datetime.now()
    hora = f"{hora_atual.hour}:{hora_atual.minute}:{hora_atual.second}"
    data_atual = datetime.date.today()
    data = data_atual.strftime("%d/%m/%Y")
    id = random.randint(100, 900)
    nome = request.POST.get("nome")
    cpf = request.POST.get("cpf")
    produtos = list(Finalizar.objects.all())

    for item in produtos:
        produto = get_object_or_404(Produto, nome_produto=item.nome_produto)
        produto.qtd -= item.quant  # Subtract the purchased quantity from the product's stock
        produto.save()

    Retirado.objects.create(
        nome_cliente=nome,
        cpf_cliente=cpf,
        id_compra=id,
        data=data,
        hora=hora,
        total_pagar=pFinal
    )

    Finalizar.objects.all().delete()
    Carrinho.objects.all().delete()

    return render(request, 'nota_fiscal.html', {
        "produtos": produtos,
        "hora_atual": hora_atual,
        "data": data,
        "preco_final": pFinal,
        "id": id,
        "nome": nome,
        "cpf": cpf
    })
# contato
def botContato(request):
    return render(request, 'contato.html')

def enviarCont(request):
    cnome = request.POST.get("nome")
    cemail = request.POST.get("email")
    cassunto = request.POST.get("assunto")
    cmensagem = request.POST.get("mensagem")
    Contato.objects.create(nome=cnome, email=cemail, assunto=cassunto, mensagem=cmensagem)
    return redirect(fcliente)

def sobre_nos(request):
    return render(request, 'sobre_nos.html')

# relatorio dos produtos
def relatorio(request):
    produtos = Retirado.objects.all()
    return render(request, 'relatorio.html', {"produtos":produtos})

def deleteRela(request, id):
    produto = Retirado.objects.get(id=id)
    produto.delete()
    return redirect(relatorio)

def mensagem(request):
    mensagens = Contato.objects.all()
    return render(request, 'mensagem.html', {"mensagens":mensagens})