from django.db import models

# Create your models here.
class Cliente(models.Model):
    nome = models.CharField(max_length=60)
    def __str__(self):
        return self.nome

    email = models.CharField(max_length=100)
    def __str__(self):
        return self.email

    senha = models.CharField(max_length=15)
    def __str__(self):
        return self.senha

    cpf = models.CharField(max_length=11)
    def __str__(self):
        return self.cpf

    telefone = models.CharField(max_length=15)
    def __str__(self):
        return self.telefone

class Produto(models.Model):
    nome_produto = models.CharField(max_length=60)
    tipo = models.CharField(max_length=15)
    qtd = models.IntegerField(default=0)
    preco = models.FloatField(default=0)
    descricao = models.TextField(null=True, blank=True)
    imagem = models.ImageField(upload_to='imagens/', null=True, blank=True)

    def __str__(self):
        return self.nome_produto

    def __str__(self):
        return self.descricao

class Carrinho(models.Model):
    nome_produto = models.CharField(max_length=60)
    quant = models.IntegerField(default=0)
    preco = models.FloatField(default=0)

    def __str__(self):
        return self.nome_produto


class Finalizar(models.Model):
    nome_produto = models.CharField(max_length=60)
    quant = models.IntegerField(default=0)
    preco = models.FloatField(default=0)
    preco_final = models.FloatField(default=0)

    def __str__(self):
        return self.nome_produto
    
class Contato(models.Model):
    nome = models.CharField(max_length=60)
    def __str__(self):
        return self.nome

    email = models.CharField(max_length=100)
    def __str__(self):
        return self.email
    
    assunto = models.CharField(max_length=60)
    def __str__(self):
        return self.assunto
    
    mensagem = models.TextField(null=True, blank=True)

class Retirado(models.Model):
    nome_cliente = models.CharField(max_length=60)
    cpf_cliente = models.CharField(max_length=15)
    id_compra = models.CharField(max_length=60)
    data = models.CharField(max_length=60)
    hora = models.CharField(max_length=60)
    total_pagar = models.FloatField(default=0)

    def __str__(self):
        return self.nome_cliente