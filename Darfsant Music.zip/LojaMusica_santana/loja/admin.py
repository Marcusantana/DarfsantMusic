from django.contrib import admin
from .models import Cliente, Produto, Carrinho, Finalizar, Contato
# Register your models here.
admin.site.register(Cliente)
admin.site.register(Produto)
admin.site.register(Carrinho)
admin.site.register(Finalizar)
admin.site.register(Contato)
