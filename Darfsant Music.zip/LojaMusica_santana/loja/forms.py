from django import forms
from .models import Produto

class ProdutoForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = ['nome_produto', 'tipo', 'qtd','preco', 'descricao', 'imagem']
        widgets = {
            'imagem': forms.FileInput(),
        }